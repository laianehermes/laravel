<?php namespace estoque\Commands;

abstract class Command {

	//

}
